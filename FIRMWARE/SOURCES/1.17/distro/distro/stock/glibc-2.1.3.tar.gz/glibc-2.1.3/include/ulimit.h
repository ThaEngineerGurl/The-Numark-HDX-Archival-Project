#ifndef _ULIMIT_H
#include <resource/ulimit.h>

/* Now define the internal interfaces.  */
extern long int __ulimit __P ((int __cmd, ...));
#endif
