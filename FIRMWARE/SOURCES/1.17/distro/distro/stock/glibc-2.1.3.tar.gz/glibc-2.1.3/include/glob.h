#ifndef	_GLOB_H
#include <posix/glob.h>

/* Now define the internal interfaces.  */
extern int __glob_pattern_p __P ((__const char *__pattern, int __quote));

#endif
