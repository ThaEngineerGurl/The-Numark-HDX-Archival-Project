#ifndef _SYS_FILE_H
#include <misc/sys/file.h>

/* Now define the internal interfaces.  */
extern int __flock __P ((int __fd, int __operation));
#endif
