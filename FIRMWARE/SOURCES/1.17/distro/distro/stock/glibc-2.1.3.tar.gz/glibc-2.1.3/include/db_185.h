#ifndef _DB_185_H_
#include <db2/db_185.h>

/* Now define the internal interfaces.  */
DB *__dbopen __P((const char *, int, int, DBTYPE, const void *));
#endif
