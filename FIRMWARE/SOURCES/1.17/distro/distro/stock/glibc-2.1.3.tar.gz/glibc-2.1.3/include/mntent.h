#ifndef _MNTENT_H
#include <misc/mntent.h>

/* Now define the internal interfaces.  */
extern FILE *__setmntent __P ((__const char *__file, __const char *__mode));
extern struct mntent *__getmntent_r __P ((FILE *__stream,
					  struct mntent *__result,
					  char *__buffer, int __bufsize));
extern int __addmntent __P ((FILE *__stream, __const struct mntent *__mnt));
extern int __endmntent __P ((FILE *__stream));
extern char *__hasmntopt __P ((__const struct mntent *__mnt,
			       __const char *__opt));
#endif
