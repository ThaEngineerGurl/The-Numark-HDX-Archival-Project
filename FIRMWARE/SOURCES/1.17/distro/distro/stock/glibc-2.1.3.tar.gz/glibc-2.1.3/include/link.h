#include <elf/link.h>
