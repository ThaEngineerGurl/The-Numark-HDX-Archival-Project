/* whattime.h --- see whattime.c for explanation */

#ifndef __WHATTIME_H
#define __WHATTIME_H

extern void print_uptime(void);
extern char *sprint_uptime(void);

#endif
