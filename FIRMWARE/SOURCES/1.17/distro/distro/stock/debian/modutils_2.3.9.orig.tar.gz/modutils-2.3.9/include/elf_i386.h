/* Machine-specific elf macros for i386 et al.  */
#ident "$Id: elf_i386.h 1.1 Wed, 25 Aug 1999 16:26:49 +1000 keith $"

#define ELFCLASSM	ELFCLASS32
#define ELFDATAM	ELFDATA2LSB

#define MATCH_MACHINE(x)  (x == EM_386 || x == EM_486)

#define SHT_RELM	SHT_REL
#define Elf32_RelM	Elf32_Rel
