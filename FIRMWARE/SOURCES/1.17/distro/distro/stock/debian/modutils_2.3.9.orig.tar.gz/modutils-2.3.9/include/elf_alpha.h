/* Machine-specific elf macros for the Alpha.  */
#ident "$Id: elf_alpha.h 1.1 Wed, 25 Aug 1999 16:26:49 +1000 keith $"

#define ELFCLASSM	ELFCLASS64
#define ELFDATAM	ELFDATA2LSB

#define MATCH_MACHINE(x)  (x == EM_ALPHA)

#define SHT_RELM	SHT_RELA
#define Elf64_RelM	Elf64_Rela
