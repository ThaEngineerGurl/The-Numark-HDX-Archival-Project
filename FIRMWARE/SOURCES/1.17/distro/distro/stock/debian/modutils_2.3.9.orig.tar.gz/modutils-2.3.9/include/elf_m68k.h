/* Machine-specific elf macros for m68k.  */
#ident "$Id: elf_m68k.h 1.1 Wed, 25 Aug 1999 16:26:49 +1000 keith $"

#define ELFCLASSM	ELFCLASS32
#define ELFDATAM	ELFDATA2MSB

#define MATCH_MACHINE(x)  (x == EM_68K)

#define SHT_RELM	SHT_RELA
#define Elf32_RelM	Elf32_Rela
