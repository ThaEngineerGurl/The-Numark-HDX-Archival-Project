/* Machine-specific elf macros for MIPS.  */
#ident "$Id: elf_mips.h 1.1 Wed, 25 Aug 1999 16:26:49 +1000 keith $"

#define ELFCLASSM	ELFCLASS32
#ifdef __MIPSEB__
#define ELFDATAM	ELFDATA2MSB
#endif
#ifdef __MIPSEL__
#define ELFDATAM	ELFDATA2LSB
#endif

#define MATCH_MACHINE(x)  (x == EM_MIPS || x == EM_MIPS_RS4_BE)

#define SHT_RELM	SHT_REL
#define Elf32_RelM	Elf32_Rel
