/* Machine-specific elf macros for the PowerPC.  */
#ident "$Id: elf_ppc.h 1.1 Wed, 25 Aug 1999 16:26:49 +1000 keith $"

#define ELFCLASSM	ELFCLASS32
#define ELFDATAM	ELFDATA2MSB

#define MATCH_MACHINE(x)  (x == EM_PPC)

#define SHT_RELM	SHT_RELA
#define Elf32_RelM	Elf32_Rela
