/* Machine-specific elf macros for the Sparc.  */
#ident "$Id: elf_sparc.h 1.1 Wed, 25 Aug 1999 16:26:49 +1000 keith $"

#define ELFCLASSM	ELFCLASS32
#define ELFDATAM	ELFDATA2MSB

#define MATCH_MACHINE(x)  (x == EM_SPARC)

#define SHT_RELM	SHT_RELA
#define Elf32_RelM	Elf32_Rela
