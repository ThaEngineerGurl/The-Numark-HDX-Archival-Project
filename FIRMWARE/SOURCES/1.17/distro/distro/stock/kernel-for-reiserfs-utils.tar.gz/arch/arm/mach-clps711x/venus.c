/*
 *  linux/arch/arm/mach-clps711x/venus.c
 *
 *  Copyright (C) 2000 Deep Blue Solutions Ltd
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
#include <linux/config.h>
#include <linux/init.h>
#include <linux/types.h>
#include <linux/string.h>

#include <asm/hardware.h>
#include <asm/io.h>
#include <asm/setup.h>
#include <asm/mach-types.h>
#include <asm/mach/arch.h>
#include <asm/pgtable.h>
#include <asm/page.h>
#include <asm/mach/map.h>

extern void clps711x_init_irq(void);

static void __init
fixup_venus(struct machine_desc *desc, struct param_struct *params,
	    char **cmdline, struct meminfo *mi)
{
	params->u1.s.page_size		= 4096;
	params->u1.s.nr_pages		= 2048;
	params->u1.s.mem_fclk_21285	= 0;
	params->u1.s.rd_start		= 0;
	params->u1.s.ramdisk_size	= 4096;
	params->u1.s.flags		= FLAG_RDLOAD;
	params->u1.s.system_rev		= 0;
	params->u1.s.system_serial_low	= 0;
	params->u1.s.system_serial_high	= 0;
	params->u1.s.rootdev		= 0x0100;

	/* Ramdisk is kept in flash. Remember to use the "keepinitrd"
	   parameter in the commandline as we can't free this space! */
	params->u1.s.initrd_start	= FLASH_VIRT_BASE+0xd0000;
	params->u1.s.initrd_size	= 0x30000;

	/* 2 banks of 4MB - discontiguous memory */
	mi->nr_banks = 2;

	mi->bank[0].start=0xc0000000;
	mi->bank[0].size=4*1024*1024;
	mi->bank[0].node=0;

	mi->bank[1].start=0xd0000000;
	mi->bank[1].size=4*1024*1024;
	mi->bank[1].node=1;

	strcpy(params->commandline, *cmdline);
}

static struct map_desc venus_io_desc[] __initdata = {
  { MISC_VIRT_BASE, MISC_PHYS_BASE, 1048576, DOMAIN_IO, 1, 1, 0, 0 },
  { IDE_VIRT_BASE, IDE_PHYS_BASE, 1048576, DOMAIN_IO, 1, 1, 0, 0 },
  { CLPS7111_VIRT_BASE, CLPS7111_PHYS_BASE, 1048576, DOMAIN_IO, 0, 1, 0, 0 },
  LAST_DESC
};

void __init venus_map_io(void)
{
	iotable_init(venus_io_desc);
}

MACHINE_START(VENUS, "Rio Venus")
	MAINTAINER("empeg ltd")
	BOOT_MEM(0xc0000000, 0x80000000, 0xff000000)
	BOOT_PARAMS(0xc0000100)
	FIXUP(fixup_venus)
	MAPIO(venus_map_io)
	INITIRQ(clps711x_init_irq)
MACHINE_END

static int venus_hw_init(void)
{
	return 0;
}

__initcall(venus_hw_init);

