/*
 * linux/arch/arm/mach-sa1100/jupiter.c
 */

#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/tty.h>

#include <asm/hardware.h>
#include <asm/setup.h>

#include <asm/mach/arch.h>
#include <asm/mach/map.h>

#include "generic.h"


static void __init
fixup_jupiter(struct machine_desc *desc, struct param_struct *params,
	      char **cmdline, struct meminfo *mi)
{
        char *candidate_cmdline = (char*)0xC0000000;

	if ( *candidate_cmdline >= 'a'
	     && *candidate_cmdline <= 'z'
	     && memchr(candidate_cmdline, '\0', 256)
	     && strchr(candidate_cmdline, '=') ) {
		*cmdline = candidate_cmdline;
		/*printk("fixup_jupiter: seem to have found cmdline %s\n",
		  candidate_cmdline); */
	}

	/* 0xd0000 is the offset of the ramdisk in the flash (see
	   makeupgrade.cpp). Note "keepinitrd" must be set in the
	   commandline, as we cannot free non-RAM areas! */
	setup_ramdisk( 1, 0, 0, 4096 );
	setup_initrd( FLASH_VIRT_BASE+0xd0000, 192*1024 );
}

static struct map_desc jupiter_io_desc[] __initdata = {
  { FLASH_VIRT_BASE, FLASH_PHYS_BASE, 0x02000000, DOMAIN_IO, 1, 1, 0, 0 }, /* Flash */
  LAST_DESC
};

static void __init jupiter_map_io(void)
{
	sa1100_map_io();
	iotable_init(jupiter_io_desc);
}

MACHINE_START(JUPITER, "Rio Jupiter")
	MAINTAINER("Hugo Fiennes")
	BOOT_MEM(0xc0000000, 0x80000000, 0xf8000000)
        BOOT_PARAMS(0xc0000400)
        FIXUP(fixup_jupiter)
	MAPIO(jupiter_map_io)
	INITIRQ(sa1100_init_irq)
MACHINE_END
