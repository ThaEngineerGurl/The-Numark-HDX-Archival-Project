extern void assabet_leds_event(led_event_t evt);
extern void brutus_leds_event(led_event_t evt);
extern void cerf_leds_event(led_event_t evt);
extern void graphicsclient_leds_event(led_event_t evt);
extern void lart_leds_event(led_event_t evt);
extern void pfs168_leds_event(led_event_t evt);
