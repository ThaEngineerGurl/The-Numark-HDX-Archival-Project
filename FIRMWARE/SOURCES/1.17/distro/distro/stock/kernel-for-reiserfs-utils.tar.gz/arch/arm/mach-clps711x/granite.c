/*
 *  linux/arch/arm/mach-clps711x/granite.c
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
#include <linux/config.h>
#include <linux/init.h>
#include <linux/types.h>
#include <linux/string.h>

#include <asm/hardware.h>
#include <asm/io.h>
#include <asm/setup.h>
#include <asm/mach-types.h>
#include <asm/mach/arch.h>
#include <asm/pgtable.h>
#include <asm/page.h>
#include <asm/mach/map.h>

extern void clps711x_init_irq(void);

static void __init
fixup_granite(struct machine_desc *desc, struct param_struct *params,
	      char **cmdline, struct meminfo *mi)
{
	params->u1.s.page_size		= 4096;
	params->u1.s.nr_pages		= 4096;
	params->u1.s.mem_fclk_21285	= 0;
	params->u1.s.rd_start		= 0;
	params->u1.s.ramdisk_size	= 4096;
	params->u1.s.flags		= FLAG_RDLOAD;
	params->u1.s.system_rev		= 0;
	params->u1.s.system_serial_low	= 0;
	params->u1.s.system_serial_high	= 0;
	params->u1.s.rootdev		= 0x0100;

	/* Ramdisk is kept in flash. Remember to use the "keepinitrd"
	   parameter in the commandline as we can't free this space! */
	params->u1.s.initrd_start	= FLASH_VIRT_BASE+0xd0000;
	params->u1.s.initrd_size	= 0x30000;

	strcpy(params->commandline, *cmdline);
}

static struct map_desc granite_io_desc[] __initdata = {
  { IDE_VIRT_BASE, IDE_PHYS_BASE, 1048576, DOMAIN_IO, 1, 1, 0, 0 },
  { USB_VIRT_BASE, USB_PHYS_BASE, 1048576, DOMAIN_IO, 1, 1, 0, 0 },
  { MISC_VIRT_BASE, MISC_PHYS_BASE, 1048576, DOMAIN_IO, 1, 1, 0, 0 },
  { SRAM_VIRT_BASE, SRAM_PHYS_BASE, 1048576, DOMAIN_IO, 1, 1, 0, 0 },
  { CLPS7111_VIRT_BASE, CLPS7111_PHYS_BASE, 1048576, DOMAIN_IO, 0, 1, 0, 0 },
  { FLASH_VIRT_BASE, FLASH_PHYS_BASE, 1048576, DOMAIN_IO, 1, 1, 0, 0 },
  LAST_DESC
};

void __init granite_map_io(void)
{
	iotable_init(granite_io_desc);
}

MACHINE_START(GRANITE, "Rio Granite")
	MAINTAINER("empeg ltd")
	BOOT_MEM(0xc0000000, 0x80000000, 0xff000000)
	BOOT_PARAMS(0xc0000100)
	FIXUP(fixup_granite)
	MAPIO(granite_map_io)
	INITIRQ(clps711x_init_irq)
MACHINE_END

static int granite_hw_init(void)
{
	return 0;
}

__initcall(granite_hw_init);

