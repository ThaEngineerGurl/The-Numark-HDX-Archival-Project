/*
 *  linux/arch/arm/mm/discontig.c
 * from mm-sa1100.c
 *
 *  Copyright (C) 1998-1999 Russell King
 *  Copyright (C) 1999 Hugo Fiennes
 *
 *  Discontiguous memory support.
 */

#include <linux/mm.h>
#include <linux/init.h>
#include <linux/bootmem.h>

#if (NR_NODES != 2) && (NR_NODES != 4)
#error Fix Me Please
#endif

/*
 * Our node_data structure for discontigous memory.
 */

static bootmem_data_t node_bootmem_data[NR_NODES];

pg_data_t discontig_node_data[NR_NODES] = {
#if NR_NODES == 2
  { bdata: &node_bootmem_data[0] },
  { bdata: &node_bootmem_data[1] }
#else
  { bdata: &node_bootmem_data[0] },
  { bdata: &node_bootmem_data[1] },
  { bdata: &node_bootmem_data[2] },
  { bdata: &node_bootmem_data[3] }
#endif
};
